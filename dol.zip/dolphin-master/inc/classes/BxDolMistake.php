<?php

require_once('Thing.php');

class BxDolMistake extends Thing
{
    function BxDolMistake()
    {
    }
    function log ($s)
    {
    }
    function displayError ()
    {
    }
}
