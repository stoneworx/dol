<?php
/***************************************************************************
*
* IMPORTANT: This is a commercial product made by BoonEx Ltd. and cannot be modified for other than personal usage.
* This product cannot be redistributed for free or a fee without written permission from BoonEx Ltd.
* This notice may not be removed from the source code.
*
***************************************************************************/

/**
 * URL of sounds folder.
 */
$sSoundsUrl = $sModulesUrl . $sModule . "/data/sounds/";

/**
 * URL of users files  folder.
 */
$sFilesUrl = $sModulesUrl . $sModule . "/files/";

/**
 * Path of users files folder.
 */
$sFilesPath = $sModulesPath . $sModule . "/files/";

/**
 * RMS server application
 */
$sServerApp = "im";
