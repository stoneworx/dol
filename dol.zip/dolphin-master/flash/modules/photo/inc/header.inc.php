<?php
/***************************************************************************
*
* IMPORTANT: This is a commercial product made by BoonEx Ltd. and cannot be modified for other than personal usage.
* This product cannot be redistributed for free or a fee without written permission from BoonEx Ltd.
* This notice may not be removed from the source code.
*
***************************************************************************/

$sFilesUrl = $sModulesUrl . $sModule . "/files/";
$sFilesPath = $sModulesPath . $sModule . "/files/";
